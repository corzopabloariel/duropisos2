<?php $__env->startSection('headTitle', 'Productos | Duro pisos'); ?>
<?php $__env->startSection('bodyTitle', 'Productos'); ?>

<?php $__env->startSection('body'); ?>
<main>
    <?php switch($tipo):
        case ('familia'): ?>
            <div class="container">
                <div class="card">
                    <div class="card-content">
                        <span class="card-title">Familia de productos<button class="btn right" onclick="addRegistro('pfamilia')"><i class="material-icons">add_circle</i></button></span>
                    </div>
                    <div class="card-content table">
                        <table class="striped">
                            <thead>
                                <th>Imagen</th>
                                <th>Título</th>
                                <th class="text-center">Orden</th>
                                <th class="text-center">Acciones</th>
                            </thead>
                            <tbody>
                                <?php if(count($familias) != 0): ?>
                                    <?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr data-id="<?php echo e($familia['id']); ?>">
                                            <td><img src="<?php echo e(asset('img/').'/'.$familia['image']); ?>" style="height:50px;" /></td>
                                            <td><?php echo e($familia["title"]); ?></td>
                                            <td class="text-center"><?php echo e($familia["order"]); ?></td>
                                            <td class="text-center">
                                                <button type="button" class="btn btn-primary" onclick="edit('pfamilia',<?php echo e($familia['id']); ?>)"><i class="material-icons">create</i></button>
                                                <button type="button" class="btn btn-danger" onclick="erase('pfamilia',<?php echo e($familia['id']); ?>)"><i class="material-icons">delete</i></button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr class="vacio">
                                        <td colspan="4">SIN DATOS</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php break; ?>;
        <?php case ('uno'): ?>
            <div class="card">
                <div class="card-content">
                    <span class="card-title">Productos<button onclick="addRegistro('producto')" class="btn right"><i class="fas fa-plus"></i></button></span>
                </div>
                <div class="card-content table">
                    <table class="striped">
                        <thead>
                            <th>Código</th>
                            <th>Imagen</th>
                            <th>Título</th>
                            <th>Familia</th>
                            <th class="text-center">Orden</th>
                            <th class="text-center">Acciones</th>
                        </thead>
                        <tbody>
                            <?php if(count($productos) != 0): ?>
                            <?php $__currentLoopData = $productos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-id="<?php echo e($producto['id']); ?>">
                                    <td><?php echo e($producto["codigo"]); ?></td>
                                    <td><img src="<?php echo e(asset('img/').'/'.$producto['image']); ?>" style="height:50px;" /></td>
                                    <td><?php echo e($producto["name"]); ?></td>
                                    <td><?php echo e($familias[$producto["pfamilia_id"]]); ?></td>
                                    <td class="text-center"><?php echo e($producto["order"]); ?></td>
                                    <td class="text-center">
                                        <button type="button" class="btn btn-primary" onclick="edit('producto',<?php echo e($producto['id']); ?>)"><i class="material-icons">create</i></button>
                                        <button type="button" class="btn btn-danger" onclick="erase('producto',<?php echo e($producto['id']); ?>)"><i class="material-icons">delete</i></button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                            <tr class="vacio">
                                <td colspan="6">SIN DATOS</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <?php break; ?>;
    <?php endswitch; ?>
</main>
<script src="//cdn.ckeditor.com/4.7.3/full/ckeditor.js"></script>
<script>
    window.familias = <?php echo json_encode($familias); ?>;
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>