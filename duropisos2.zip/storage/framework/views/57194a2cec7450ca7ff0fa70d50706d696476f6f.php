<?php $__env->startSection('headTitle', 'Home | Duro Pisos'); ?>
<?php $__env->startSection('bodyTitle', 'Home'); ?>

<?php $__env->startSection('body'); ?>
<?php echo $__env->make('public.basico.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<main>
    <!-- SLIDER -->
    
    <div class="carousel carousel-slider center">
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="carousel-item" style="background-image: url(<?php echo e(asset('img')); ?>/<?php echo e($slider['image']); ?>); background-position: top center; background-repeat: no-repeat; background-size: cover;" href="#<?php echo e($slider['id']); ?>!">
        <?php echo $slider["texto"]; ?>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <!-- FAMILIA DE PRODUCTOS -->

    <article class="wrapper-familias">
        <div class="row familias">
            <?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="align-items-center">
                <img src="<?php echo e(asset('img')); ?>/<?php echo e($familia['image']); ?>" />
                <p><?php echo $familia["title"]; ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </article>
    <article class="wrapper-empresa-home bg-F9F9F9">
        <div class="container">
            <div class="row m-0">
                <div class="col l6 s12">
                    <img src="<?php echo e(asset('img')); ?>/<?php echo e($data['image_resume']); ?>" />
                </div>
                <div class="col l6 s12">
                    <p class="m-0 text-uppercase"><?php echo e($data["title_resume"]); ?></p>
                    <h4 class="text_importante" style="margin-top:0"><?php echo e($data["subtitle_resume"]); ?></h4>
                    <?php echo $data['text_resume']; ?>

                    <a href="<?php echo e(URL::to($path . '/empresa')); ?>" class="btn-solo">nuestra empresa</a>
                </div>
            </div>
        </div>
    </article>

    <article class="wrapper-servicio">
        <span></span>
        <div class="container">
            <div class="row m-0">
                <p class="text-uppercase m-0 text-center">servicio integral</p>
                <h4 style="margin-top:0" class="text-center">Garantía y respaldo</h4>
                <div class="row servicios">
                    <?php $__currentLoopData = $servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col s12 l4">
                        <img src="<?php echo e(asset('img')); ?>/<?php echo e($servicio['icon']); ?>" />
                        <p><?php echo $servicio["title"]; ?></p>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </article>
</main>

<?php echo $__env->make('public.basico.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<!-- Servicio -->
<?php echo $__env->make('public.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>