<?php $__env->startSection('headTitle', 'Producto :: ' . $title . ' | Duro Pisos'); ?>
<?php $__env->startSection('bodyTitle', 'Producto :: ' . $title); ?>

<?php $__env->startSection('body'); ?>
<?php echo $__env->make('public.basico.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<main>
    <div class="container">
        <div class="image-producto">
            <div class="row">
                <div class="col s12">
                    <?php if(!empty($producto)): ?>
                    <img src="<?php echo e(asset('img')); ?>/<?php echo e($producto['image']); ?>" alt="Producto - <?php echo e($title); ?>"/>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="nav-producto">
            <div class="row">
                <div class="col s12">
                    <a class="a-link" href="<?php echo e(URL::to($path . '/productos')); ?>">« Volver</a>
                </div>
            </div>
            <div class="row">
                <div class="col s12 l6">
                    <h4 class="m-0 text-title"><?php echo e($title); ?></h4>
                </div>
                <div class="col s12 l6 text-right">
                    <div class="mercadolibre">
                        <?php if(!empty($producto["url_mercadolibre"])): ?>
                        <a href="<?php echo e($producto['url_mercadolibre']); ?>" target="blank"><img src="<?php echo e(asset('img/general')); ?>/mercadolibre.fw.png" alt="Mercadolibre"/></a>
                        <?php endif; ?>
                        <?php if(!empty($producto["url_mercadopago"])): ?>
                        <a href="<?php echo e($producto['url_mercadopago']); ?>" target="blank"><img src="<?php echo e(asset('img/general')); ?>/mercadopago.fw.png" alt="Mercadopago"/></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php if(!empty($producto["descripcion"])): ?>
            <div class="row">
                <div class="col s12 l3">
                    <p class="text-titulo text-uppercase">descripción</p>
                </div>
                <div class="col s12 l9 text_principal_595959"><?php echo $producto["descripcion"]; ?></div>
            </div>
            <?php endif; ?>
            <?php if(!empty($producto["ventaja"])): ?>
            <div class="row">
                <div class="col s12 l3">
                    <p class="text-titulo text-uppercase">ventajas</p>
                </div>
                <div class="col s12 l9 text_principal_595959 ventajas"><?php echo $producto["ventaja"]; ?></div>
            </div>
            <?php endif; ?>
            <?php if(!empty($producto["presentacion"])): ?>
            <div class="row">
                <div class="col s12 l3">
                    <p class="text-titulo text-uppercase">presentación</p>
                </div>
                <div class="col s12 l9 text_principal_595959 presentacion"><?php echo $producto["presentacion"]; ?></div>
            </div>
            <?php endif; ?>
            <?php if(!empty($producto["color"])): ?>
            <div class="row">
                <div class="col s12 l3">
                    <p class="text-titulo text-uppercase">colores</p>
                </div>
                <div class="col s12 l9 text_principal_595959">
                    <?php echo $producto["color"]; ?>

                    <div class="colores">
                        <?php $__currentLoopData = $producto["colores"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="" data-descripcion="<?php echo $color['descripcion']; ?>">
                                <img src="<?php echo e(asset('img')); ?>/<?php echo e($color['image']); ?>" alt="Color - <?php echo e($color['name']); ?>"/>
                                <p><?php echo e($color["code"]); ?> <?php echo $color["name"]; ?></p>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</main>
<?php echo $__env->make('public.basico.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>