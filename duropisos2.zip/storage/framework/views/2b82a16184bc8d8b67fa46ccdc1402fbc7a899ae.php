<?php $__env->startSection('headTitle', 'Empresa | Duro Pisos'); ?>
<?php $__env->startSection('bodyTitle', 'Empresa'); ?>

<?php $__env->startSection('body'); ?>
<?php echo $__env->make('public.basico.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<main>
    <!-- SLIDER -->
    
    <div class="carousel carousel-slider center">
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="carousel-item" style="background-image: url(<?php echo e(asset('img')); ?>/<?php echo e($slider['image']); ?>); background-position: top center; background-repeat: no-repeat; background-size: cover;" href="#<?php echo e($slider['id']); ?>!">
        <?php echo $slider["texto"]; ?>

        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <article class="wrapper-empresa-home">
        <div class="container">
            <div class="row m-0">
                <div class="col l6 s12">
                    <img src="<?php echo e(asset('img')); ?>/<?php echo e($data['image']); ?>" />
                </div>
                <div class="col l6 s12">
                    <p class="m-0 text-uppercase"><?php echo e($data["title"]); ?></p>
                    <h4 class="text_importante" style="margin-top:0"><?php echo e($data["subtitle"]); ?></h4>
                    <?php echo $data['text']; ?>

                </div>
            </div>
        </div>
    </article>
</main>
<?php echo $__env->make('public.basico.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>