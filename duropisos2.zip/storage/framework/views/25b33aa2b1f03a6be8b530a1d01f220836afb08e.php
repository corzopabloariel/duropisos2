<?php $__env->startSection('headTitle', $seccion . ' | Duro pisos'); ?>
<?php $__env->startSection('bodyTitle', $seccion); ?>

<?php $__env->startSection('body'); ?>
<main>
    
    <?php switch($seccion):
        case ("ventaja"): ?>
        <div class="container">
            <div class="card">
                <div class="card-content">
                    <span class="card-title">Ventajas<button onclick="addRegistro('ventaja')" class="btn right"><i class="fas fa-plus"></i></button></span>
                </div>
                <div class="card-content table">
                    <table>
                        <thead>
                            <th>Ícono</th>
                            <th>Título</th>
                            <th>Orden</th>
                            <th style="width:150px">Acciones</th>
                        </thead>
                        <tbody>
                            <?php if(count($ventajas) != 0): ?>
                                <?php $__currentLoopData = $ventajas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ventaja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr data-id="<?php echo e($ventaja['id']); ?>">
                                        <td><img src="<?php echo e(asset('img/').'/'.$ventaja['icon']); ?>" style="height:50px;" /></td>
                                        <td><?php echo e($ventaja["title"]); ?></td>
                                        <td class="text-center"><?php echo e($ventaja["order"]); ?></td>
                                        <td class="text-center">
                                            <button type="button" class="btn btn-primary" onclick="edit('ventaja',<?php echo e($ventaja['id']); ?>)"><i class="material-icons">create</i></button>
                                            <button type="button" class="btn btn-danger" onclick="erase('ventaja',<?php echo e($ventaja['id']); ?>)"><i class="material-icons">delete</i></button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr class="vacio">
                                    <td colspan="4">SIN DATOS</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php break; ?>;
        <?php case ("pregunta"): ?>
        <div class="card">
            <div class="card-content">
                <span class="card-title">Preguntas<button onclick="addRegistro('pregunta')" class="btn right"><i class="fas fa-plus"></i></button></span>
            </div>
            <div class="card-content table">
                <table>
                    <thead>
                        <th>Pregunta</th>
                        <th>Respuesta</th>
                        <th>Orden</th>
                        <th style="width:150px">Acciones</th>
                    </thead>
                    <tbody>
                        <?php if(count($preguntas) != 0): ?>
                            <?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-id="<?php echo e($pregunta['id']); ?>">
                                    <td><?php echo e($pregunta["pregunta"]); ?></td>
                                    <td><?php echo e($pregunta["respuesta"]); ?></td>
                                    <td class="text-center"><?php echo e($pregunta["order"]); ?></td>
                                    <td class="text-center">
                                        <button type="button" class="btn btn-primary" onclick="edit('pregunta',<?php echo e($pregunta['id']); ?>)"><i class="material-icons">create</i></button>
                                        <button type="button" class="btn btn-danger" onclick="erase('pregunta',<?php echo e($pregunta['id']); ?>)"><i class="material-icons">delete</i></button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr class="vacio">
                                <td colspan="4">SIN DATOS</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php break; ?>;
        <?php case ("aplicacion"): ?>
        <div class="container">
            <div class="card">
                <div class="card-content">
                    <span class="card-title">Aplicaciones<button onclick="addRegistro('aplicacion')" class="btn right"><i class="fas fa-plus"></i></button></span>
                </div>
                <div class="card-content table">
                    <table>
                        <thead>
                            <th>Link</th>
                            <th>Título</th>
                            <th>Orden</th>
                            <th style="width:150px">Acciones</th>
                        </thead>
                        <tbody>
                            <?php if(count($aplicaciones) != 0): ?>
                                <?php $__currentLoopData = $aplicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aplicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr data-id="<?php echo e($aplicacion['id']); ?>">
                                        <td><a href="https://www.youtube.com/watch?v=<?php echo e($aplicacion['video']); ?>" target="blank">https://www.youtube.com/watch?v=<?php echo e($aplicacion['video']); ?></a></td>
                                        <td><?php echo e($aplicacion["title"]); ?></td>
                                        <td class="text-center"><?php echo e($aplicacion["order"]); ?></td>
                                        <td class="text-center">
                                            <button type="button" class="btn btn-primary" onclick="edit('aplicacion',<?php echo e($aplicacion['id']); ?>)"><i class="material-icons">create</i></button>
                                            <button type="button" class="btn btn-danger" onclick="erase('aplicacion',<?php echo e($aplicacion['id']); ?>)"><i class="material-icons">delete</i></button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <tr class="vacio">
                                    <td colspan="4">SIN DATOS</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php break; ?>;
        <?php case ("trabajo"): ?>
        <div class="card">
            <div class="card-content">
                <span class="card-title">Trabajos realizados<button onclick="addRegistro('trabajo')" class="btn right"><i class="fas fa-plus"></i></button></span>
            </div>
            <div class="card-content table">
                <table class="striped">
                    <thead>
                        <th>Imagen</th>
                        <th>Título</th>
                        <th>Familia</th>
                        <th>Tipo</th>
                        <th>Orden</th>
                        <th style="width:150px">Acciones</th>
                    </thead>
                    <tbody>
                        <?php if(count($trabajos) != 0): ?>
                            <?php $__currentLoopData = $trabajos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabajo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-id="<?php echo e($trabajo['id']); ?>">
                                    <td><img src="<?php echo e(asset('img/').'/'.$trabajo['image']); ?>" style="height:50px;" /></td>
                                    <td><?php echo e($trabajo["title"]); ?></td>
                                    <td><?php echo e($familias[$trabajo["pfamilia_id"]]); ?></td>
                                    <td><?php echo e($tipo[$trabajo["is_profesional"]."".$trabajo["is_particular"]]); ?></td>
                                    <td class="text-center"><?php echo e($trabajo["order"]); ?></td>
                                    <td class="text-center">
                                        <button type="button" class="btn btn-primary" onclick="edit('trabajo',<?php echo e($trabajo['id']); ?>)"><i class="material-icons">create</i></button>
                                        <button type="button" class="btn btn-danger" onclick="erase('trabajo',<?php echo e($trabajo['id']); ?>)"><i class="material-icons">delete</i></button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr class="vacio">
                                <td colspan="6">SIN DATOS</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <script>
            window.familias = <?php echo json_encode($familias); ?>;
        </script>
        <?php break; ?>;
    <?php endswitch; ?>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>