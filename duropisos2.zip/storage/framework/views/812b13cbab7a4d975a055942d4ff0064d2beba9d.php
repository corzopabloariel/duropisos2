<?php $__env->startSection('headTitle', 'Trabajos realizados | Duro Pisos'); ?>
<?php $__env->startSection('bodyTitle', 'Trabajos realizados'); ?>

<?php $__env->startSection('body'); ?>
<?php echo $__env->make('public.basico.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<main style="padding:4em 0;">
    <div class="container">
        <fieldset class="fieldset-title">
            <legend>
                <p class="text-center text-uppercase">trabajos realizados</p>
                <h4>Proyectos</h4>
            </legend>
        </fieldset>
        <div class="row tipos">
            <div class="col s12">
                <a href="#" data-tipo="0" class="activo">Todos</a>
                <?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="#" data-tipo="<?php echo e($k); ?>"><?php echo e($v); ?></a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="row trabajos" style="padding-top:2em;">
            <?php $__currentLoopData = $trabajos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trabajo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col l4 m6 s12" data-tipo="<?php echo e($trabajo['pfamilia_id']); ?>" data-profesional="<?php echo e($trabajo['is_profesional']); ?>" data-particular="<?php echo e($trabajo['is_particular']); ?>">
                    <img class="materialboxed" src="<?php echo e(asset('img')); ?>/<?php echo e($trabajo['image']); ?>" />
                    <p><?php echo $trabajo["title"]; ?></p>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</main>
<?php echo $__env->make('public.basico.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>