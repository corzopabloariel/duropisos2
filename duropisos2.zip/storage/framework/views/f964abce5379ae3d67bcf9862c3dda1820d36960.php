<?php $__env->startSection('headTitle', 'Preguntas frecuentes | Duro Pisos'); ?>
<?php $__env->startSection('bodyTitle', 'Preguntas frecuentes'); ?>

<?php $__env->startSection('body'); ?>
<?php echo $__env->make('public.basico.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<main style="padding:4em 0;">
    <div class="container">
        <fieldset class="fieldset-title">
            <legend>
                <p class="text-center text-uppercase">preguntas frecuentes</p>
                <h4>Más información</h4>
            </legend>
        </fieldset>
        <ul class="collapsible box-shadow-none m-0">
            <?php $__currentLoopData = $preguntas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pregunta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li>
                    <div class="collapsible-header"><?php echo e($pregunta["pregunta"]); ?></div>
                    <div class="collapsible-body"><?php echo $pregunta["respuesta"]; ?></div>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</main>
<?php echo $__env->make('public.basico.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>