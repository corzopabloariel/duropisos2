<?php $__env->startSection('headTitle', 'Aplicación | Duro Pisos'); ?>
<?php $__env->startSection('bodyTitle', 'Aplicación'); ?>

<?php $__env->startSection('body'); ?>
<?php echo $__env->make('public.basico.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<main style="padding:4em 0;">
    <div class="container">
        <fieldset class="fieldset-title">
            <legend>
                <p class="text-center text-uppercase">instructivos en video</p>
                <h4>Aplicación</h4>
            </legend>
        </fieldset>
        <div class="row">
        <?php $__currentLoopData = $aplicaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aplicacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col l4 m6 s12">
                <div class="card-video">
                    <iframe style="width:100%" src="https://www.youtube.com/embed/<?php echo e($aplicacion['video']); ?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                <div class="">
                    <?php echo $aplicacion["title"]; ?>

                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</main>
<?php echo $__env->make('public.basico.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>