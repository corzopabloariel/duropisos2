<?php $__env->startSection('headTitle', 'Ventajas | Duro Pisos'); ?>
<?php $__env->startSection('bodyTitle', 'Ventajas'); ?>

<?php $__env->startSection('body'); ?>
<?php echo $__env->make('public.basico.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<main style="padding:4em 0;">
    <div class="container">
        <fieldset class="fieldset-title">
            <legend>
                <p class="text-center text-uppercase">conocé nuestras</p>
                <h4>Ventajas</h4>
            </legend>
        </fieldset>
        <div class="row ventajas">
            <?php $__currentLoopData = $ventajas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ventaja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col l4 m4 s12">
                    <div class="d-flex align-items-center">
                        <img src="<?php echo e(asset('img')); ?>/<?php echo e($ventaja['icon']); ?>" />
                        <p><?php echo $ventaja["title"]; ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</main>
<?php echo $__env->make('public.basico.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>