<?php $__env->startSection('headTitle', 'Usuarios | Duro pisos'); ?>
<?php $__env->startSection('bodyTitle', 'Usuarios'); ?>

<?php $__env->startSection('body'); ?>
<main>
    <div class="container">
        <div class="card">
            <div class="card-content">
                <span class="card-title">Usuarios del sistema<button onclick="addRegistro('usuario')" class="btn right"><i class="fas fa-plus"></i></button></span>
            </div>
            <div class="card-content table">
                <table>
                    <thead>
                        <th>Nombre</th>
                        <th>Usuario</th>
                        <th>Nivel</th>
                        <th style="width:150px">Acciones</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-id="<?php echo e($usuario['id']); ?>">
                                <td><?php echo e($usuario["name"]); ?></td>
                                <td><?php echo e($usuario["username"]); ?></td>
                                <td><?php echo ($usuario["is_admin"] ? "Administrador" : "Usuario"); ?></td>
                                <td class="text-center">
                                    <?php if(Auth::user()["id"] != $usuario["id"]): ?>
                                        <button type="button" class="btn btn-primary" onclick="edit('usuario',<?php echo e($usuario['id']); ?>)"><i class="material-icons">create</i></button>
                                        <button type="button" class="btn btn-danger" onclick="erase('usuario',<?php echo e($usuario['id']); ?>)"><i class="material-icons">delete</i></button>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('usuario', ['seccion' => 'datos'])); ?>">Ir a DATOS DE USUARIO</a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>