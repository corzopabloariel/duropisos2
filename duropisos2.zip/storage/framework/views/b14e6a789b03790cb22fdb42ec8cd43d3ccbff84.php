<?php $__env->startSection('headTitle', 'Productos | Duro Pisos'); ?>
<?php $__env->startSection('bodyTitle', 'Productos'); ?>

<?php $__env->startSection('body'); ?>
<?php echo $__env->make('public.basico.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<main style="padding:4em 0;">
    <div class="container">
        <fieldset class="fieldset-title">
            <legend>
                <p class="text-center text-uppercase">conocé nuestros</p>
                <h4>Productos</h4>
            </legend>
        </fieldset>

        <div class="row trabajos" style="padding-top:2em;">
            <?php $__currentLoopData = $familias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $familia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo URL::to('particular/productos/'); ?>/<?php echo e($familia['url']); ?>" class="col l4 m4 s12 text_principal_444444">
                    <img src="<?php echo e(asset('img')); ?>/<?php echo e($familia['image']); ?>" />
                    <p class="text-center" style="padding-top:1em;"><?php echo $familia["title"]; ?></p>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</main>
<?php echo $__env->make('public.basico.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('public.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>