@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-4 position-absolute">
            {{-- Listado --}}
        </div>
        <div class="col-8 position-relative">
            
        </div>
    </div>
</div>
@endsection
