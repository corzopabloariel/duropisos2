@extends('public.main')

@section('headTitle', 'Home | Duro Pisos')
@section('bodyTitle', 'Home')

@section('body')
@include('public.basico.header')
<main>
    asdasd
</main>
@include('public.basico.footer')
@endsection