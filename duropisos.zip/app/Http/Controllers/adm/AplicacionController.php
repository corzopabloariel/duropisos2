<?php

namespace App\Http\Controllers\adm;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class AplicacionController extends Controller
{
    public function index() {
        dd("create");
    }
}
