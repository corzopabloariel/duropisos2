<?php

namespace App\Http\Controllers\adm;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class MetadatosController extends Controller
{
    public function index() {
        dd("metadatos");
    }
}
