<?php $__env->startSection('headTitle', 'Empresa | Duro pisos'); ?>
<?php $__env->startSection('bodyTitle', 'Empresa'); ?>

<?php $__env->startSection('body'); ?>
<main>
    <div class="row">
        <div class="col s6">
            <form>
                <fieldset>
                    <legend><button type="button" onclick="editEmpresa('data')" class="btn">Domicilio <i class="material-icons right">send</i></button></legend>
                    <?php if(empty($empresaData)): ?>
                    <div class="row">
                        <div class=" col s12">
                            <p style="margin-bottom:0">SIN DATOS</p>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="row">
                        <div class=" col s12">
                            <label for="domicilio">Domicilio</label>
                            <p style="margin-bottom:0"><?php echo e($empresaData["direccion"]); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class=" col s6">
                            <label for="provincia_id">Provincia</label>
                            <p style="margin-bottom:0"><?php echo e($empresaData["provincia_id"]); ?></p>
                        </div>
                        <div class=" col s6">
                            <label for="localidad_id">Localidad</label>
                            <p style="margin-bottom:0"><?php echo e($empresaData["localidad_id"]); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class=" col s6">
                            <label>Logotipo</label>
                            <img style="width:100%; margin:0 auto;" onError="this.src='<?php echo e(asset('img/general/no-img.png')); ?>'" src="<?php echo e(asset('img/')); ?>/<?php echo e($empresaData['logo_principal']); ?>" />
                        </div>
                        <div class=" col s6">
                            <label>Logotipo footer</label>
                            <img style="width:100%; margin:0 auto;" onError="this.src='<?php echo e(asset('img/general/no-img.png')); ?>'" src="<?php echo e(asset('img/')); ?>/<?php echo e($empresaData['logo_footer']); ?>" />
                        </div>
                    </div>
                    <div class="row">
                        <div class=" col s6">
                            <label>Favicon</label>
                            <img style="width:96px; display:block; margin:0 auto;" onError="this.src='<?php echo e(asset('img/general/no-img.png')); ?>'" src="<?php echo e(asset('img/')); ?>/<?php echo e($empresaData['favicon']); ?>" />
                        </div>
                    </div>
                    <?php endif; ?>
                </fieldset>
            </form>
        </div>
        <div class="col s6">
            <form>
                <fieldset>
                    <legend><button type="button" onclick="editEmpresa('contacto')" class="btn">Contacto <i class="material-icons right">send</i></button></legend>
                    <?php if(empty($empresaContacto)): ?>
                    <div class="row">
                        <div class=" col s12">
                            <p style="margin-bottom:0">SIN DATOS</p>
                        </div>
                    </div>
                    <?php else: ?>
                    <div class="row">
                        <div class=" col s12">
                            <label>Email 1</label>
                            <?php if(!empty($empresaContacto["email_1"])): ?>
                                <p style="margin-bottom:0"><?php echo e($empresaContacto["email_1"]); ?></p>
                            <?php else: ?>
                                <p style="margin-bottom:0">SIN DATO</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class=" col s12">
                            <label>Email 2</label>
                            <?php if(!empty($empresaContacto["email_2"])): ?>
                                <p style="margin-bottom:0"><?php echo e($empresaContacto["email_2"]); ?></p>
                            <?php else: ?>
                                <p style="margin-bottom:0">SIN DATO</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class=" col s12">
                            <label>Teléfono</label>
                            <?php if(!empty($empresaContacto["telefono_1"])): ?>
                                <p style="margin-bottom:0"><?php echo e($empresaContacto["telefono_1"]); ?></p>
                            <?php else: ?>
                                <p style="margin-bottom:0">SIN DATO</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class=" col s6">
                            <label>Facebook</label>
                            <?php if(!empty($empresaContacto["facebook"])): ?>
                                <p style="margin-bottom:0"><a href="<?php echo e($empresaContacto['facebook']); ?>" target="blank"><?php echo e($empresaContacto["facebook"]); ?></a></p>
                            <?php else: ?>
                                <p style="margin-bottom:0">SIN DATO</p>
                            <?php endif; ?>
                        </div>
                        <div class=" col s6">
                            <label>Instagram</label>
                            <?php if(!empty($empresaContacto["instagram"])): ?>
                                <p style="margin-bottom:0"><a href="<?php echo e($empresaContacto['instagram']); ?>" target="blank"><?php echo e($empresaContacto["instagram"]); ?></a></p>
                            <?php else: ?>
                                <p style="margin-bottom:0">SIN DATO</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </fieldset>
            </form>
        </div>
    </div>
    <script>
        window.provincias = <?php echo json_encode($provincias); ?>;
    </script>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>