<?php $__env->startSection('headTitle', 'Editar Slider | Duro pisos'); ?>
<?php $__env->startSection('bodyTitle', 'Editar Slider'); ?>

<?php $__env->startSection('body'); ?>
<main>
    <div class="container">
        <div class="card">
            <div class="card-content">
                <span class="card-title">Slider<button onclick="addRegistro('slider<?php echo e($section); ?>')" class="btn right"><i class="fas fa-plus"></i></button></span>
                <table>
                    <thead>
                        <th>Imagen</th>
                        <th>Texto</th>
                        <th>Orden</th>
                        <th style="width:150px">Acciones</th>
                    </thead>
                    <tbody>
                        <?php if(count($sliders) != 0): ?>
                            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr data-id="<?php echo e($slider['id']); ?>">
                                    <td><img src="<?php echo e(asset('img/').'/'.$slider['image']); ?>" style="height:50px;" /></td>
                                    <td><?php echo $slider["texto"]; ?></td>
                                    <td class="text-center"><?php echo e($slider["order"]); ?></td>
                                    <td class="text-center">
                                        <button type="button" class="btn btn-primary" onclick="edit('slider',<?php echo e($slider['id']); ?>)"><i class="material-icons">create</i></button>
                                        <button type="button" class="btn btn-danger" onclick="erase('slider',<?php echo e($slider['id']); ?>)"><i class="material-icons">delete</i></button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr class="vacio">
                                <td colspan="4">SIN DATOS</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>

<script src="//cdn.ckeditor.com/4.7.3/full/ckeditor.js"></script>
<script>
	// 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>