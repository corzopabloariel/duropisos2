<?php $__env->startSection('headTitle', 'Bienvenido | Duro Pisos'); ?>
<?php $__env->startSection('bodyTitle', 'Bienvenido'); ?>

<?php $__env->startSection('body'); ?>
<main>
    <div class="bg_index" style="height: 100vh; margin-bottom:0;">
        <div class="d-flex align-items-center justify-content-center" style="height: inherit">
            <div class="row w-100">
                <div class="col s8 offset-s2 bg-white-o">
                    <div class="row p-3 m-0">
                        <div class="col s6">
                            <img class="mx-auto d-block w-100" src="<?php echo e(asset('img/logo/logo.png')); ?>"/>
                            <p style="margin-bottom:0;" class="text-center text-uppercase text_importante">elegí un tipo de usuario</p>
                        </div>
                        <div class="col s6 text-center">
                            <a href="<?php echo e(route('profesional')); ?>" class="img-profesional">
                                <span></span>
                                <p style="margin-bottom:0">Profesional</p>
                            </a>
                            <a href="<?php echo e(route('particular')); ?>" class="img-particular">
                                <span></span>
                                <p style="margin-bottom:0">Particular</p>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('public.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>