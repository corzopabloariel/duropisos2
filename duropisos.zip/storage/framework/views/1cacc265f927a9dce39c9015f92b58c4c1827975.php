<?php $__env->startSection('headTitle', 'Home | Duro Pisos'); ?>
<?php $__env->startSection('bodyTitle', 'Home'); ?>

<?php $__env->startSection('body'); ?>
<main>
    
    <div class="row" style="height: 100vh; margin-bottom:0;">
        <div class="d-flex" style="height: inherit">
            <h3 class="text-bienvenido">Bienvenido</h3>
        </div>
    </div>
</main>

<script src="//cdn.ckeditor.com/4.7.3/full/ckeditor.js"></script>
<script>
	// CKEDITOR.replace('titulo');
	// CKEDITOR.replace('subtitulo');
	// CKEDITOR.config.width = '100%';
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>